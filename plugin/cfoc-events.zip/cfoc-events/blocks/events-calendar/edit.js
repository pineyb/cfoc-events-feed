( function ( wp ) {
	var el = wp.element.createElement;
	var __ = wp.i18n.__;
	var useBlockProps = wp.blockEditor.useBlockProps;
	var InspectorControls = wp.blockEditor.InspectorControls;
	var PanelBody = wp.components.PanelBody;
	var SelectControl = wp.components.SelectControl;
	var ToggleControl = wp.components.ToggleControl;
	var ServerSideRender = wp.serverSideRender;
	var useSelect = wp.data.useSelect;

	wp.blocks.registerBlockType( 'cfoc/events-calendar', {
		edit: function ( props ) {
			var a = props.attributes;
			var set = props.setAttributes;
			var types = useSelect( function ( select ) {
				return select( 'core' ).getEntityRecords( 'taxonomy', 'cfoc_event_type', { per_page: 100 } ) || [];
			}, [] );

			return el(
				'div',
				useBlockProps(),
				el(
					InspectorControls,
					null,
					el(
						PanelBody,
						{ title: __( 'Calendar settings', 'cfoc-events' ) },
						el( SelectControl, {
							label: __( 'Opens in', 'cfoc-events' ),
							value: a.initialView,
							options: [
								{ label: __( 'Upcoming list', 'cfoc-events' ), value: 'list' },
								{ label: __( 'Month calendar', 'cfoc-events' ), value: 'calendar' },
							],
							onChange: function ( v ) { set( { initialView: v } ); },
						} ),
						el( SelectControl, {
							label: __( 'Only show this event type', 'cfoc-events' ),
							value: a.eventType,
							options: [ { label: __( 'All types', 'cfoc-events' ), value: '' } ].concat(
								types.map( function ( t ) { return { label: t.name, value: t.slug }; } )
							),
							onChange: function ( v ) { set( { eventType: v } ); },
						} ),
						el( ToggleControl, {
							label: __( 'Show search & type filter', 'cfoc-events' ),
							checked: a.showFilters,
							onChange: function ( v ) { set( { showFilters: v } ); },
						} ),
						el( ToggleControl, {
							label: __( 'Include past events in list', 'cfoc-events' ),
							checked: a.showPast,
							onChange: function ( v ) { set( { showPast: v } ); },
						} ),
						el( ToggleControl, {
							label: __( 'Show neutrality / subscribe footer', 'cfoc-events' ),
							checked: a.showFooter,
							onChange: function ( v ) { set( { showFooter: v } ); },
						} )
					)
				),
				el( ServerSideRender, { block: 'cfoc/events-calendar', attributes: a } )
			);
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp );
