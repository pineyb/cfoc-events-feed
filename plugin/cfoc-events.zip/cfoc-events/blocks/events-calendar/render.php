<?php
/**
 * Server render for cfoc/events-calendar.
 *
 * Outputs the full upcoming list as real HTML (for search engines, no-JS visitors and
 * the editor preview), the event data as JSON, and schema.org Event markup.
 * view.js upgrades it into the interactive calendar / list.
 *
 * @var array $attributes
 */

defined( 'ABSPATH' ) || exit;

$today     = current_time( 'Y-m-d' );
$from      = gmdate( 'Y-m-d', strtotime( $today . ' -13 months' ) );
$all       = cfoc_events_get( array( 'from' => $from, 'type' => $attributes['eventType'] ) );
$upcoming  = array_values(
	array_filter(
		$all,
		function ( $e ) use ( $today ) {
			return $e['end'] >= $today;
		}
	)
);
$types     = get_terms(
	array(
		'taxonomy'   => 'cfoc_event_type',
		'hide_empty' => true,
	)
);
$type_list = is_wp_error( $types ) ? array() : wp_list_pluck( $types, 'name' );
$last_sync = get_option( 'cfoc_events_last_verified_run', '' );

$config = array(
	'events'      => $all,
	'types'       => array_values( $type_list ),
	'today'       => $today,
	'initialView' => $attributes['initialView'],
	'showFilters' => (bool) $attributes['showFilters'],
	'showPast'    => (bool) $attributes['showPast'],
	'icsUrl'      => rest_url( 'cfoc-events/v1/ics' ),
);

$dialog_id = wp_unique_id( 'cfoc-events-dialog-' );
$wrapper   = get_block_wrapper_attributes( array( 'class' => 'cfoc-events' ) );

// schema.org markup for upcoming events.
$ld = array();
foreach ( array_slice( $upcoming, 0, 50 ) as $e ) {
	$item = array(
		'@context'            => 'https://schema.org',
		'@type'               => 'Event',
		'name'                => $e['title'],
		'startDate'           => $e['start'],
		'endDate'             => $e['end'],
		'eventAttendanceMode' => $e['online'] ? 'https://schema.org/OnlineEventAttendanceMode' : 'https://schema.org/OfflineEventAttendanceMode',
		'location'            => $e['online']
			? array( '@type' => 'VirtualLocation', 'url' => $e['url'] )
			: array(
				'@type'   => 'Place',
				'name'    => $e['venue'] ? $e['venue'] : $e['location'],
				'address' => $e['location'],
			),
	);
	if ( $e['url'] ) {
		$item['url'] = $e['url'];
	}
	if ( $e['organizer'] ) {
		$item['organizer'] = array( '@type' => 'Organization', 'name' => $e['organizer'] );
	}
	if ( $e['description'] ) {
		$item['description'] = $e['description'];
	}
	$ld[] = $item;
}
?>
<div <?php echo $wrapper; // phpcs:ignore WordPress.Security.EscapeOutput ?>>
	<div class="cfoc-events__panel">
		<div class="cfoc-events__tools" hidden>
			<div class="cfoc-events__search">
				<input type="search" class="cfoc-events__q" placeholder="<?php esc_attr_e( 'Search events, organizers or locations…', 'cfoc-events' ); ?>" aria-label="<?php esc_attr_e( 'Search events', 'cfoc-events' ); ?>">
				<select class="cfoc-events__type" aria-label="<?php esc_attr_e( 'Filter event type', 'cfoc-events' ); ?>">
					<option value=""><?php esc_html_e( 'All event types', 'cfoc-events' ); ?></option>
				</select>
			</div>
			<div class="cfoc-events__switch" role="group" aria-label="<?php esc_attr_e( 'View format', 'cfoc-events' ); ?>">
				<button type="button" data-view="list"><?php esc_html_e( 'Upcoming', 'cfoc-events' ); ?></button>
				<button type="button" data-view="calendar"><?php esc_html_e( 'Calendar', 'cfoc-events' ); ?></button>
			</div>
		</div>

		<div class="cfoc-events__body" aria-live="polite">
			<?php if ( empty( $upcoming ) ) : ?>
				<p class="cfoc-events__empty"><?php esc_html_e( 'No upcoming events are listed yet.', 'cfoc-events' ); ?></p>
			<?php else : ?>
				<div class="cfoc-events__list">
					<?php
					$current_month = '';
					foreach ( $upcoming as $e ) :
						$month = wp_date( 'F Y', strtotime( $e['start'] ), new DateTimeZone( 'UTC' ) );
						if ( $month !== $current_month ) :
							$current_month = $month;
							?>
							<h3 class="cfoc-events__month"><?php echo esc_html( $month ); ?></h3>
						<?php endif; ?>
						<article class="cfoc-events__entry">
							<div class="cfoc-events__date">
								<strong><?php echo esc_html( wp_date( 'M j', strtotime( $e['start'] ), new DateTimeZone( 'UTC' ) ) ); ?></strong>
								<span><?php echo esc_html( $e['start'] === $e['end'] ? __( 'One day', 'cfoc-events' ) : __( 'Multi-day', 'cfoc-events' ) ); ?></span>
							</div>
							<div class="cfoc-events__content">
								<h4>
									<?php echo esc_html( $e['title'] ); ?>
									<?php if ( $e['type'] ) : ?>
										<span class="cfoc-events__tag"><?php echo esc_html( $e['type'] ); ?></span>
									<?php endif; ?>
									<?php if ( $e['unconfirmed'] ) : ?>
										<span class="cfoc-events__tag is-unconfirmed"><?php esc_html_e( 'Dates unconfirmed', 'cfoc-events' ); ?></span>
									<?php endif; ?>
								</h4>
								<p class="cfoc-events__meta">
									<?php echo esc_html( implode( ' · ', array_filter( array( $e['online'] ? __( 'Online', 'cfoc-events' ) : $e['location'], cfoc_events_format_range( $e['start'], $e['end'] ), $e['organizer'] ) ) ) ); ?>
								</p>
							</div>
							<?php if ( $e['url'] ) : ?>
								<a class="cfoc-events__link" href="<?php echo esc_url( $e['url'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Official site ↗', 'cfoc-events' ); ?></a>
							<?php endif; ?>
						</article>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>

		<?php if ( $attributes['showFooter'] ) : ?>
			<div class="cfoc-events__bottom">
				<span><strong><?php esc_html_e( 'Neutral by design.', 'cfoc-events' ); ?></strong> <?php esc_html_e( 'Events are listed chronologically, without sponsored placement or preference. Always confirm details on the organizer’s site.', 'cfoc-events' ); ?></span>
				<span>
					<?php if ( $last_sync ) : ?>
						<?php
						/* translators: %s: date */
						printf( esc_html__( 'Last reviewed %s', 'cfoc-events' ), esc_html( wp_date( 'M j, Y', strtotime( $last_sync ) ) ) );
						?>
						 ·
					<?php endif; ?>
					<a href="<?php echo esc_url( $config['icsUrl'] ); ?>"><?php esc_html_e( 'Subscribe (.ics)', 'cfoc-events' ); ?></a>
				</span>
			</div>
		<?php endif; ?>
	</div>
	<script type="application/json" class="cfoc-events__data"><?php echo wp_json_encode( $config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE ); ?></script>
	<?php if ( $ld ) : ?>
		<script type="application/ld+json"><?php echo wp_json_encode( $ld, JSON_HEX_TAG | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ); ?></script>
	<?php endif; ?>
	<dialog class="cfoc-events__dialog" aria-labelledby="<?php echo esc_attr( $dialog_id ); ?>">
		<div class="cfoc-events__modal">
			<button type="button" class="cfoc-events__close" aria-label="<?php esc_attr_e( 'Close', 'cfoc-events' ); ?>">✕</button>
			<h3 id="<?php echo esc_attr( $dialog_id ); ?>" class="cfoc-events__d-title"></h3>
			<p class="cfoc-events__d-desc"></p>
			<dl class="cfoc-events__d-list"></dl>
			<div class="cfoc-events__d-actions"></div>
		</div>
	</dialog>
</div>
