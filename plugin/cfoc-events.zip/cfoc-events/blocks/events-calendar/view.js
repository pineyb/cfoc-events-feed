/* CfOC Industry Events — front-end calendar/list. No dependencies. */
( function () {
	'use strict';

	var MONTHS = [ 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' ];
	var MON = MONTHS.map( function ( m ) { return m.slice( 0, 3 ); } );

	function parse( s ) {
		var p = s.split( '-' ).map( Number );
		return new Date( p[ 0 ], p[ 1 ] - 1, p[ 2 ] );
	}
	function key( d ) {
		return d.getFullYear() + '-' + String( d.getMonth() + 1 ).padStart( 2, '0' ) + '-' + String( d.getDate() ).padStart( 2, '0' );
	}
	function fmt( s, withYear ) {
		var d = parse( s );
		return MON[ d.getMonth() ] + ' ' + d.getDate() + ( withYear === false ? '' : ', ' + d.getFullYear() );
	}
	function range( e ) {
		if ( e.start === e.end ) { return fmt( e.start ); }
		var a = parse( e.start ), b = parse( e.end );
		if ( a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() ) {
			return MON[ a.getMonth() ] + ' ' + a.getDate() + '–' + b.getDate() + ', ' + b.getFullYear();
		}
		if ( a.getFullYear() === b.getFullYear() ) {
			return fmt( e.start, false ) + ' – ' + fmt( e.end );
		}
		return fmt( e.start ) + ' – ' + fmt( e.end );
	}
	function el( tag, cls, text ) {
		var n = document.createElement( tag );
		if ( cls ) { n.className = cls; }
		if ( text !== undefined && text !== null ) { n.textContent = text; }
		return n;
	}
	function googleCal( e ) {
		var end = parse( e.end ); end.setDate( end.getDate() + 1 );
		var p = new URLSearchParams( {
			action: 'TEMPLATE',
			text: e.title,
			dates: e.start.replace( /-/g, '' ) + '/' + key( end ).replace( /-/g, '' ),
			details: ( e.description ? e.description + '\n\n' : '' ) + ( e.url || '' ),
			location: e.online ? 'Online' : [ e.venue, e.location ].filter( Boolean ).join( ', ' ),
		} );
		return 'https://calendar.google.com/calendar/render?' + p.toString();
	}

	function init( root ) {
		var dataNode = root.querySelector( '.cfoc-events__data' );
		if ( ! dataNode ) { return; }
		var cfg;
		try { cfg = JSON.parse( dataNode.textContent ); } catch ( err ) { return; }

		var events = cfg.events || [];
		var today = cfg.today;
		var t = parse( today );
		var state = { view: cfg.initialView || 'list', year: t.getFullYear(), month: t.getMonth(), q: '', type: '' };

		var tools = root.querySelector( '.cfoc-events__tools' );
		var body = root.querySelector( '.cfoc-events__body' );
		var search = root.querySelector( '.cfoc-events__q' );
		var select = root.querySelector( '.cfoc-events__type' );
		var dialog = root.querySelector( '.cfoc-events__dialog' );

		if ( cfg.showFilters ) {
			tools.hidden = false;
			( cfg.types || [] ).forEach( function ( type ) {
				var o = el( 'option', null, type ); o.value = type; select.appendChild( o );
			} );
		} else {
			// Keep the view switch even when search/filter is hidden.
			tools.hidden = false;
			root.querySelector( '.cfoc-events__search' ).hidden = true;
		}

		search.addEventListener( 'input', function () { state.q = search.value.trim().toLowerCase(); render(); } );
		select.addEventListener( 'change', function () { state.type = select.value; render(); } );
		root.querySelectorAll( '.cfoc-events__switch button' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () { state.view = b.getAttribute( 'data-view' ); render(); } );
		} );
		root.querySelector( '.cfoc-events__close' ).addEventListener( 'click', function () { dialog.close(); } );
		dialog.addEventListener( 'click', function ( ev ) { if ( ev.target === dialog ) { dialog.close(); } } );

		function matches( e ) {
			if ( state.type && ( e.types || [] ).indexOf( state.type ) === -1 ) { return false; }
			if ( ! state.q ) { return true; }
			return [ e.title, e.location, e.venue, e.organizer, e.type, e.region, e.description ].join( ' ' ).toLowerCase().indexOf( state.q ) !== -1;
		}

		function detail( e ) {
			root.querySelector( '.cfoc-events__d-title' ).textContent = e.title;
			root.querySelector( '.cfoc-events__d-desc' ).textContent = e.description || '';
			var dl = root.querySelector( '.cfoc-events__d-list' );
			dl.replaceChildren();
			[ [ 'Dates', range( e ) ], [ 'Location', e.online ? 'Online' : e.location ], [ 'Venue', e.venue ], [ 'Organizer', e.organizer ], [ 'Type', ( e.types || [] ).join( ', ' ) ], [ 'Status', e.unconfirmed ? 'Dates not yet confirmed on the organizer’s site' : '' ], [ 'Verified', e.lastVerified ? fmt( e.lastVerified ) : '' ] ].forEach( function ( row ) {
				if ( ! row[ 1 ] ) { return; }
				dl.appendChild( el( 'dt', null, row[ 0 ] ) );
				dl.appendChild( el( 'dd', null, row[ 1 ] ) );
			} );
			var actions = root.querySelector( '.cfoc-events__d-actions' );
			actions.replaceChildren();
			if ( e.url ) {
				var a = el( 'a', 'cfoc-events__action', 'Official event page ↗' );
				a.href = e.url; a.target = '_blank'; a.rel = 'noopener';
				actions.appendChild( a );
			}
			var g = el( 'a', 'cfoc-events__action is-secondary', 'Add to Google Calendar' );
			g.href = googleCal( e ); g.target = '_blank'; g.rel = 'noopener';
			actions.appendChild( g );
			if ( typeof dialog.showModal === 'function' ) { dialog.showModal(); } else if ( e.url ) { window.open( e.url, '_blank' ); }
		}

		function head() {
			var h = el( 'div', 'cfoc-events__head' );
			if ( state.view === 'calendar' ) {
				h.appendChild( el( 'h2', null, MONTHS[ state.month ] + ' ' + state.year ) );
				var nav = el( 'div', 'cfoc-events__nav' );
				var prev = el( 'button', null, '←' ); prev.type = 'button'; prev.setAttribute( 'aria-label', 'Previous month' );
				var now = el( 'button', null, 'This month' ); now.type = 'button';
				var next = el( 'button', null, '→' ); next.type = 'button'; next.setAttribute( 'aria-label', 'Next month' );
				prev.onclick = function () { state.month--; if ( state.month < 0 ) { state.month = 11; state.year--; } render(); };
				next.onclick = function () { state.month++; if ( state.month > 11 ) { state.month = 0; state.year++; } render(); };
				now.onclick = function () { state.year = t.getFullYear(); state.month = t.getMonth(); render(); };
				nav.append( prev, now, next );
				h.appendChild( nav );
			} else {
				h.appendChild( el( 'h2', null, cfg.showPast ? 'All events' : 'Upcoming events' ) );
			}
			return h;
		}

		function listView( filtered ) {
			var wrap = el( 'div', 'cfoc-events__list' );
			var list = filtered.filter( function ( e ) { return cfg.showPast || e.end >= today; } );
			if ( ! list.length ) {
				wrap.appendChild( el( 'p', 'cfoc-events__empty', 'No events match. Try clearing your search or filter.' ) );
				return wrap;
			}
			var current = '';
			list.forEach( function ( e ) {
				var d = parse( e.start );
				var m = MONTHS[ d.getMonth() ] + ' ' + d.getFullYear();
				if ( m !== current ) { current = m; wrap.appendChild( el( 'h3', 'cfoc-events__month', m ) ); }
				var item = el( 'article', 'cfoc-events__entry' + ( e.end < today ? ' is-past' : '' ) );
				var date = el( 'div', 'cfoc-events__date' );
				date.appendChild( el( 'strong', null, fmt( e.start, false ) ) );
				date.appendChild( el( 'span', null, e.start === e.end ? 'One day' : 'Multi-day' ) );
				var c = el( 'div', 'cfoc-events__content' );
				var h = el( 'h4', null, e.title );
				if ( e.type ) { h.appendChild( el( 'span', 'cfoc-events__tag', e.type ) ); }
				if ( e.unconfirmed ) { h.appendChild( el( 'span', 'cfoc-events__tag is-unconfirmed', 'Dates unconfirmed' ) ); }
				c.appendChild( h );
				c.appendChild( el( 'p', 'cfoc-events__meta', [ e.online ? 'Online' : e.location, range( e ), e.organizer ].filter( Boolean ).join( ' · ' ) ) );
				var b = el( 'button', 'cfoc-events__more', 'Details' ); b.type = 'button';
				b.onclick = function () { detail( e ); };
				item.append( date, c, b );
				wrap.appendChild( item );
			} );
			return wrap;
		}

		function calendarView( filtered ) {
			var wrap = el( 'div', 'cfoc-events__calendar' );
			var wd = el( 'div', 'cfoc-events__weekdays' );
			[ 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat' ].forEach( function ( d ) { wd.appendChild( el( 'div', null, d ) ); } );
			var grid = el( 'div', 'cfoc-events__days' );
			var first = new Date( state.year, state.month, 1 );
			var offset = first.getDay();
			var days = new Date( state.year, state.month + 1, 0 ).getDate();
			var cells = Math.ceil( ( offset + days ) / 7 ) * 7;
			for ( var i = 0; i < cells; i++ ) {
				var date = new Date( state.year, state.month, 1 + i - offset );
				var k = key( date );
				var inMonth = date.getMonth() === state.month;
				var cell = el( 'div', 'cfoc-events__day' + ( inMonth ? '' : ' is-outside' ) + ( k === today ? ' is-today' : '' ) );
				cell.appendChild( el( 'span', 'cfoc-events__num', date.getDate() ) );
				if ( inMonth ) {
					var ev = filtered.filter( function ( e ) { return k >= e.start && k <= e.end; } );
					ev.slice( 0, 3 ).forEach( function ( e ) {
						var p = el( 'button', 'cfoc-events__pill', e.title ); p.type = 'button';
						p.title = e.title + ' · ' + ( e.online ? 'Online' : e.location );
						p.onclick = function () { detail( e ); };
						cell.appendChild( p );
					} );
					if ( ev.length > 3 ) { cell.appendChild( el( 'span', 'cfoc-events__overflow', '+' + ( ev.length - 3 ) + ' more' ) ); }
				}
				grid.appendChild( cell );
			}
			wrap.append( wd, grid );
			var ms = key( first ), me = key( new Date( state.year, state.month + 1, 0 ) );
			if ( ! filtered.some( function ( e ) { return e.start <= me && e.end >= ms; } ) ) {
				wrap.appendChild( el( 'p', 'cfoc-events__empty', 'No events this month. Use the arrows to browse, or switch to Upcoming.' ) );
			}
			return wrap;
		}

		function render() {
			root.querySelectorAll( '.cfoc-events__switch button' ).forEach( function ( b ) {
				var on = b.getAttribute( 'data-view' ) === state.view;
				b.classList.toggle( 'is-active', on );
				b.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
			} );
			var filtered = events.filter( matches );
			body.replaceChildren( head(), state.view === 'calendar' ? calendarView( filtered ) : listView( filtered ) );
		}

		root.classList.add( 'is-interactive' );
		render();
	}

	function boot() { document.querySelectorAll( '.cfoc-events' ).forEach( init ); }
	if ( document.readyState === 'loading' ) { document.addEventListener( 'DOMContentLoaded', boot ); } else { boot(); }
} )();
