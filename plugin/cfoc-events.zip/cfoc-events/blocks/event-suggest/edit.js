( function ( wp ) {
	var el = wp.element.createElement;
	var __ = wp.i18n.__;
	var useBlockProps = wp.blockEditor.useBlockProps;
	var InspectorControls = wp.blockEditor.InspectorControls;
	var PanelBody = wp.components.PanelBody;
	var TextControl = wp.components.TextControl;
	var TextareaControl = wp.components.TextareaControl;
	var ServerSideRender = wp.serverSideRender;

	wp.blocks.registerBlockType( 'cfoc/event-suggest', {
		edit: function ( props ) {
			var a = props.attributes;
			return el(
				'div',
				useBlockProps(),
				el(
					InspectorControls,
					null,
					el(
						PanelBody,
						{ title: __( 'Form text', 'cfoc-events' ) },
						el( TextControl, { label: __( 'Heading', 'cfoc-events' ), value: a.heading, onChange: function ( v ) { props.setAttributes( { heading: v } ); } } ),
						el( TextareaControl, { label: __( 'Intro', 'cfoc-events' ), value: a.intro, onChange: function ( v ) { props.setAttributes( { intro: v } ); } } )
					)
				),
				el( wp.components.Disabled, null, el( ServerSideRender, { block: 'cfoc/event-suggest', attributes: a } ) )
			);
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp );
