<?php
/**
 * Server render for cfoc/event-suggest.
 *
 * @var array $attributes
 */

defined( 'ABSPATH' ) || exit;

$status = isset( $_GET['cfoc_suggest'] ) ? sanitize_key( wp_unslash( $_GET['cfoc_suggest'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$uid    = wp_unique_id( 'cfoc-sg-' );
$types  = get_terms( array( 'taxonomy' => 'cfoc_event_type', 'hide_empty' => false ) );
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'cfoc-event-suggest' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?> id="suggest-event">
	<h3><?php echo esc_html( $attributes['heading'] ); ?></h3>
	<p class="cfoc-event-suggest__intro"><?php echo esc_html( $attributes['intro'] ); ?></p>

	<?php if ( 'thanks' === $status ) : ?>
		<div class="cfoc-event-suggest__msg is-ok" role="status"><?php esc_html_e( 'Thank you — your suggestion was received and will be reviewed before it appears on the calendar.', 'cfoc-events' ); ?></div>
	<?php elseif ( 'error' === $status ) : ?>
		<div class="cfoc-event-suggest__msg is-err" role="alert"><?php esc_html_e( 'Sorry, that did not go through. Please check the event name, start date and official link, then try again.', 'cfoc-events' ); ?></div>
	<?php endif; ?>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="cfoc_suggest_event">
		<input type="hidden" name="cfoc_return" value="<?php echo esc_url( get_permalink() ); ?>">
		<div class="cfoc-event-suggest__hp" aria-hidden="true">
			<label for="<?php echo esc_attr( $uid ); ?>-web">Website</label>
			<input id="<?php echo esc_attr( $uid ); ?>-web" type="text" name="cfoc_website" tabindex="-1" autocomplete="off">
		</div>
		<div class="cfoc-event-suggest__grid">
			<div class="is-wide">
				<label for="<?php echo esc_attr( $uid ); ?>-title"><?php esc_html_e( 'Event name', 'cfoc-events' ); ?> *</label>
				<input id="<?php echo esc_attr( $uid ); ?>-title" name="cfoc_title" required maxlength="200">
			</div>
			<div>
				<label for="<?php echo esc_attr( $uid ); ?>-start"><?php esc_html_e( 'Start date', 'cfoc-events' ); ?> *</label>
				<input id="<?php echo esc_attr( $uid ); ?>-start" type="date" name="cfoc_start" required>
			</div>
			<div>
				<label for="<?php echo esc_attr( $uid ); ?>-end"><?php esc_html_e( 'End date', 'cfoc-events' ); ?></label>
				<input id="<?php echo esc_attr( $uid ); ?>-end" type="date" name="cfoc_end">
			</div>
			<div>
				<label for="<?php echo esc_attr( $uid ); ?>-loc"><?php esc_html_e( 'City / location (or "Online")', 'cfoc-events' ); ?></label>
				<input id="<?php echo esc_attr( $uid ); ?>-loc" name="cfoc_location" maxlength="160">
			</div>
			<div>
				<label for="<?php echo esc_attr( $uid ); ?>-type"><?php esc_html_e( 'Event type', 'cfoc-events' ); ?></label>
				<select id="<?php echo esc_attr( $uid ); ?>-type" name="cfoc_type">
					<option value=""><?php esc_html_e( 'Choose…', 'cfoc-events' ); ?></option>
					<?php foreach ( is_wp_error( $types ) ? array() : $types as $t ) : ?>
						<option value="<?php echo esc_attr( $t->slug ); ?>"><?php echo esc_html( $t->name ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<div>
				<label for="<?php echo esc_attr( $uid ); ?>-org"><?php esc_html_e( 'Organizer', 'cfoc-events' ); ?></label>
				<input id="<?php echo esc_attr( $uid ); ?>-org" name="cfoc_organizer" maxlength="160">
			</div>
			<div>
				<label for="<?php echo esc_attr( $uid ); ?>-url"><?php esc_html_e( 'Official event page', 'cfoc-events' ); ?> *</label>
				<input id="<?php echo esc_attr( $uid ); ?>-url" type="url" name="cfoc_url" required placeholder="https://">
			</div>
			<div class="is-wide">
				<label for="<?php echo esc_attr( $uid ); ?>-notes"><?php esc_html_e( 'Anything else we should know?', 'cfoc-events' ); ?></label>
				<textarea id="<?php echo esc_attr( $uid ); ?>-notes" name="cfoc_notes" maxlength="1500"></textarea>
			</div>
			<div class="is-wide">
				<label for="<?php echo esc_attr( $uid ); ?>-email"><?php esc_html_e( 'Your email (optional, only used if we have a question)', 'cfoc-events' ); ?></label>
				<input id="<?php echo esc_attr( $uid ); ?>-email" type="email" name="cfoc_email" maxlength="160">
			</div>
		</div>
		<button type="submit"><?php esc_html_e( 'Suggest event', 'cfoc-events' ); ?></button>
	</form>
</div>
