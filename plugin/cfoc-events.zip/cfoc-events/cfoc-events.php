<?php
/**
 * Plugin Name:       CfOC Industry Events
 * Description:       Offsite construction industry events calendar for the Center for Offsite Construction. Adds an Events post type edited in Gutenberg, an Events Calendar block (calendar + list views), an event suggestion form block, an ICS feed, and JSON import / scheduled feed sync.
 * Version:           1.2.0
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            Center for Offsite Construction
 * License:           GPL-2.0-or-later
 * Text Domain:       cfoc-events
 */

defined( 'ABSPATH' ) || exit;

define( 'CFOC_EVENTS_VERSION', '1.2.0' );
define( 'CFOC_EVENTS_FILE', __FILE__ );
define( 'CFOC_EVENTS_DIR', plugin_dir_path( __FILE__ ) );
define( 'CFOC_EVENTS_URL', plugin_dir_url( __FILE__ ) );

require_once CFOC_EVENTS_DIR . 'includes/post-type.php';
require_once CFOC_EVENTS_DIR . 'includes/query.php';
require_once CFOC_EVENTS_DIR . 'includes/blocks.php';
require_once CFOC_EVENTS_DIR . 'includes/rest.php';
require_once CFOC_EVENTS_DIR . 'includes/ics.php';
require_once CFOC_EVENTS_DIR . 'includes/import.php';
require_once CFOC_EVENTS_DIR . 'includes/admin.php';
require_once CFOC_EVENTS_DIR . 'includes/single.php';
require_once CFOC_EVENTS_DIR . 'includes/updater.php';

register_activation_hook( __FILE__, 'cfoc_events_activate' );
register_deactivation_hook( __FILE__, 'cfoc_events_deactivate' );

function cfoc_events_activate() {
	cfoc_events_register_post_type();
	cfoc_events_register_taxonomy();
	cfoc_events_seed_default_types();
	flush_rewrite_rules();

	if ( ! wp_next_scheduled( 'cfoc_events_sync' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'cfoc_events_sync' );
	}

	// First activation: load the bundled, researched event list so the calendar isn't empty.
	if ( ! get_option( 'cfoc_events_seeded' ) ) {
		$file = CFOC_EVENTS_DIR . 'data/events.json';
		if ( file_exists( $file ) ) {
			$json = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			cfoc_events_import_json( $json, array( 'source' => 'bundled' ) );
			update_option( 'cfoc_events_bundled_hash', md5_file( $file ), false );
		}
		update_option( 'cfoc_events_seeded', 1 );
	}
}

function cfoc_events_deactivate() {
	wp_clear_scheduled_hook( 'cfoc_events_sync' );
	flush_rewrite_rules();
}
