# CfOC Industry Events (WordPress plugin)

Offsite construction industry events calendar for centerforoffsiteconstruction.org.

## What it adds
- **Industry Events** post type (admin menu) — each event is edited in Gutenberg; dates, location, venue, organizer, official link, region and verification fields live in the **Event details** sidebar panel. Event types are a taxonomy (Conference, Trade Show, Summit, Standards, Education, Policy, Workshop, Webinar).
- **Industry Events Calendar** block — upcoming list grouped by month + month calendar, search, type filter, detail pop-up with "Official event page" and "Add to Google Calendar". Server-rendered HTML + schema.org Event markup for SEO; works without JavaScript.
- **Suggest an Industry Event** block — public form; submissions arrive as **Pending** events (honeypot + rate limit, admin email notice).
- **ICS subscription feed**: `/wp-json/cfoc-events/v1/ics` · **JSON**: `/wp-json/cfoc-events/v1/events`
- **Import & Sync** screen (Industry Events → Import & Sync): upload/paste an `events.json`, set a feed URL that syncs daily via WP-Cron, export everything as JSON.
- On first activation it loads the bundled, researched list in `data/events.json`.

## Install
1. Copy the `cfoc-events` folder into `wp-content/plugins/` (or upload the zip under Plugins → Add New → Upload).
2. Activate **CfOC Industry Events**.
3. Create a page (e.g. "Industry Events"), add the **Industry Events Calendar** block (set Align → Wide) and optionally **Suggest an Industry Event** below it. Publish.
4. Settings → Permalinks → Save once if event pages 404.

## How updates work
- Feed items have a stable `id`. Re-importing updates existing events instead of duplicating them.
- `status: confirmed` → published (if auto-publish is on). `unconfirmed` → Pending for review. `cancelled` → moved to Draft.
- Turn on **Lock from automatic feed updates** on any event you hand-edit and the sync will leave it alone.
- Past events drop off the Upcoming list automatically; they stay in the database and the calendar's past months.

## Feed format
See the header comment in `includes/import.php` or `data/events.json`.
