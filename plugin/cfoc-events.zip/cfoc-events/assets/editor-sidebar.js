/* "Event details" panel in the block editor sidebar for Industry Events. */
( function ( wp ) {
	var el = wp.element.createElement;
	var __ = wp.i18n.__;
	var useSelect = wp.data.useSelect;
	var useEntityProp = wp.coreData.useEntityProp;
	var PluginDocumentSettingPanel = ( wp.editor && wp.editor.PluginDocumentSettingPanel ) || wp.editPost.PluginDocumentSettingPanel;
	var C = wp.components;

	function EventPanel() {
		var postType = useSelect( function ( s ) { return s( 'core/editor' ).getCurrentPostType(); }, [] );
		var res = useEntityProp( 'postType', 'cfoc_event', 'meta' );
		var meta = res[ 0 ] || {};
		var setMeta = res[ 1 ];
		var rawPeople = wp.element.useState( null );
		if ( postType !== 'cfoc_event' ) { return null; }

		function set( key ) {
			return function ( v ) {
				var next = {}; next[ key ] = v;
				setMeta( Object.assign( {}, meta, next ) );
			};
		}
		function text( key, label, props ) {
			return el( C.TextControl, Object.assign( { label: label, value: meta[ key ] || '', onChange: set( key ), __nextHasNoMarginBottom: true }, props || {} ) );
		}
		function today() {
			var d = new Date();
			return d.getFullYear() + '-' + String( d.getMonth() + 1 ).padStart( 2, '0' ) + '-' + String( d.getDate() ).padStart( 2, '0' );
		}

		var warn = meta.cfoc_start_date && meta.cfoc_end_date && meta.cfoc_end_date < meta.cfoc_start_date;

		return el(
			PluginDocumentSettingPanel,
			{ name: 'cfoc-event-details', title: __( 'Event details', 'cfoc-events' ), initialOpen: true },
			el( C.__experimentalVStack || 'div', { spacing: 4 },
				text( 'cfoc_start_date', __( 'Start date', 'cfoc-events' ), { type: 'date' } ),
				text( 'cfoc_end_date', __( 'End date (leave blank for one day)', 'cfoc-events' ), { type: 'date' } ),
				warn ? el( C.Notice, { status: 'warning', isDismissible: false }, __( 'End date is before start date.', 'cfoc-events' ) ) : null,
				el( C.ToggleControl, { label: __( 'Online event', 'cfoc-events' ), checked: !! meta.cfoc_online, onChange: set( 'cfoc_online' ), __nextHasNoMarginBottom: true } ),
				meta.cfoc_online ? null : text( 'cfoc_location', __( 'City / location', 'cfoc-events' ), { placeholder: 'Orlando, FL' } ),
				meta.cfoc_online ? null : text( 'cfoc_venue', __( 'Venue', 'cfoc-events' ) ),
				text( 'cfoc_organizer', __( 'Organizer', 'cfoc-events' ) ),
				text( 'cfoc_event_url', __( 'Official event page', 'cfoc-events' ), { type: 'url', placeholder: 'https://' } ),
				el( C.SelectControl, {
					label: __( 'Region', 'cfoc-events' ),
					value: meta.cfoc_region || '',
					options: [ '', 'North America', 'Europe', 'Latin America', 'Asia-Pacific', 'Middle East & Africa', 'Global / Online' ].map( function ( r ) { return { label: r || '—', value: r }; } ),
					onChange: set( 'cfoc_region' ),
					__nextHasNoMarginBottom: true,
				} ),
				el( C.TextareaControl, {
					label: __( 'CfOC people involved', 'cfoc-events' ),
					help: __( 'One per line, e.g. "Mike Nolan — Speaker". Highlights the event on the calendar.', 'cfoc-events' ),
					value: rawPeople[ 0 ] !== null ? rawPeople[ 0 ] : ( function () {
						try { return ( JSON.parse( meta.cfoc_people || '[]' ) || [] ).map( function ( p ) { return p.name + ( p.role ? ' — ' + p.role : '' ); } ).join( '\n' ); } catch ( e ) { return ''; }
					} )(),
					onChange: function ( v ) {
						rawPeople[ 1 ]( v );
						var list = v.split( '\n' ).map( function ( line ) {
							var parts = line.split( /\s+[—–-]\s+/ );
							return { name: ( parts[ 0 ] || '' ).trim(), role: ( parts[ 1 ] || '' ).trim() };
						} ).filter( function ( p ) { return p.name; } );
						set( 'cfoc_people' )( list.length ? JSON.stringify( list ) : '' );
					},
					__nextHasNoMarginBottom: true,
				} ),
				el( 'hr' ),
				text( 'cfoc_source_url', __( 'Verification source', 'cfoc-events' ), { type: 'url', help: __( 'Where the dates were confirmed (ideally the organizer’s own page).', 'cfoc-events' ) } ),
				el( 'div', { style: { display: 'flex', gap: '8px', alignItems: 'flex-end' } },
					el( 'div', { style: { flex: 1 } }, text( 'cfoc_last_verified', __( 'Last verified', 'cfoc-events' ), { type: 'date' } ) ),
					el( C.Button, { variant: 'secondary', onClick: function () { set( 'cfoc_last_verified' )( today() ); } }, __( 'Today', 'cfoc-events' ) )
				),
				el( C.ToggleControl, {
					label: __( 'Lock from automatic feed updates', 'cfoc-events' ),
					help: __( 'Turn on if you have hand-edited this event and do not want the weekly sync to overwrite it.', 'cfoc-events' ),
					checked: !! meta.cfoc_lock,
					onChange: set( 'cfoc_lock' ),
					__nextHasNoMarginBottom: true,
				} ),
				meta.cfoc_external_id ? el( 'p', { style: { color: '#757575', fontSize: '12px', margin: 0 } }, __( 'Feed ID: ', 'cfoc-events' ) + meta.cfoc_external_id ) : null
			)
		);
	}

	wp.plugins.registerPlugin( 'cfoc-event-details', { render: EventPanel, icon: 'calendar-alt' } );
} )( window.wp );
