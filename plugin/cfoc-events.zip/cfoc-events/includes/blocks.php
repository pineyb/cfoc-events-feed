<?php
/**
 * Block registration, the event-details sidebar in the editor, and the suggestion form handler.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', 'cfoc_events_register_blocks', 20 );

function cfoc_events_register_blocks() {
	wp_register_style( 'cfoc-events-style', CFOC_EVENTS_URL . 'assets/style.css', array(), CFOC_EVENTS_VERSION );
	register_block_type( CFOC_EVENTS_DIR . 'blocks/events-calendar' );
	register_block_type( CFOC_EVENTS_DIR . 'blocks/event-suggest' );
}

/**
 * "Event details" panel in the Gutenberg document sidebar for the Event post type.
 */
add_action(
	'enqueue_block_editor_assets',
	function () {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'cfoc_event' !== $screen->post_type ) {
			return;
		}
		wp_enqueue_script(
			'cfoc-events-sidebar',
			CFOC_EVENTS_URL . 'assets/editor-sidebar.js',
			array( 'wp-plugins', 'wp-edit-post', 'wp-editor', 'wp-element', 'wp-components', 'wp-data', 'wp-core-data', 'wp-i18n' ),
			CFOC_EVENTS_VERSION,
			true
		);
	}
);

/**
 * Public "suggest an event" submissions -> Pending events.
 */
add_action( 'admin_post_nopriv_cfoc_suggest_event', 'cfoc_events_handle_suggestion' );
add_action( 'admin_post_cfoc_suggest_event', 'cfoc_events_handle_suggestion' );

function cfoc_events_handle_suggestion() {
	// phpcs:disable WordPress.Security.NonceVerification -- public form on cacheable pages; protected by honeypot + rate limit, and everything lands as Pending for human review.
	$return = isset( $_POST['cfoc_return'] ) ? esc_url_raw( wp_unslash( $_POST['cfoc_return'] ) ) : home_url( '/' );
	$return = wp_validate_redirect( $return, home_url( '/' ) );
	$fail   = function () use ( $return ) {
		wp_safe_redirect( add_query_arg( 'cfoc_suggest', 'error', $return ) . '#suggest-event' );
		exit;
	};

	// Honeypot: bots fill it, people normally don't. Browser autofill sometimes does, so never discard:
	// keep the submission in Pending (it can't publish without approval) and flag it in the email.
	$flagged = ! empty( $_POST['cfoc_zq_check'] ) || ! empty( $_POST['cfoc_website'] );

	// Rate limit: 5 suggestions per IP per hour.
	$ip    = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
	$rkey  = 'cfoc_sg_' . md5( $ip );
	$count = (int) get_transient( $rkey );
	if ( $count >= 5 ) {
		$fail();
	}
	set_transient( $rkey, $count + 1, HOUR_IN_SECONDS );

	$title = isset( $_POST['cfoc_title'] ) ? sanitize_text_field( wp_unslash( $_POST['cfoc_title'] ) ) : '';
	$start = isset( $_POST['cfoc_start'] ) ? cfoc_events_sanitize_meta_date( wp_unslash( $_POST['cfoc_start'] ) ) : '';
	$end   = isset( $_POST['cfoc_end'] ) ? cfoc_events_sanitize_meta_date( wp_unslash( $_POST['cfoc_end'] ) ) : '';
	$url   = isset( $_POST['cfoc_url'] ) ? esc_url_raw( wp_unslash( $_POST['cfoc_url'] ) ) : '';
	if ( '' === $title || '' === $start || '' === $url || ! preg_match( '#^https?://[^/\s]+\.[^/\s]+#i', $url ) ) {
		$fail();
	}

	$location  = isset( $_POST['cfoc_location'] ) ? sanitize_text_field( wp_unslash( $_POST['cfoc_location'] ) ) : '';
	$organizer = isset( $_POST['cfoc_organizer'] ) ? sanitize_text_field( wp_unslash( $_POST['cfoc_organizer'] ) ) : '';
	$notes     = isset( $_POST['cfoc_notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['cfoc_notes'] ) ) : '';
	$email     = isset( $_POST['cfoc_email'] ) ? sanitize_email( wp_unslash( $_POST['cfoc_email'] ) ) : '';
	$type      = isset( $_POST['cfoc_type'] ) ? sanitize_key( wp_unslash( $_POST['cfoc_type'] ) ) : '';
	// phpcs:enable

	$post_id = wp_insert_post(
		array(
			'post_type'    => 'cfoc_event',
			'post_status'  => 'pending',
			'post_title'   => $title,
			'post_content' => '',
			'post_excerpt' => '',
		),
		true
	);
	if ( is_wp_error( $post_id ) ) {
		$fail();
	}

	$online = ( 0 === strcasecmp( trim( $location ), 'online' ) );
	update_post_meta( $post_id, 'cfoc_start_date', $start );
	update_post_meta( $post_id, 'cfoc_end_date', $end && $end >= $start ? $end : $start );
	update_post_meta( $post_id, 'cfoc_location', $online ? '' : $location );
	update_post_meta( $post_id, 'cfoc_online', $online );
	update_post_meta( $post_id, 'cfoc_organizer', $organizer );
	update_post_meta( $post_id, 'cfoc_event_url', $url );
	update_post_meta( $post_id, 'cfoc_submitter', trim( ( $flagged ? '[possible spam] ' : '' ) . $email . ( $notes ? ' — ' . $notes : '' ) ) );
	if ( $type && term_exists( $type, 'cfoc_event_type' ) ) {
		wp_set_object_terms( $post_id, $type, 'cfoc_event_type' );
	}

	$token = wp_generate_password( 32, false );
	update_post_meta( $post_id, '_cfoc_approve_token', $token );
	$approve_url = add_query_arg( array( 'action' => 'cfoc_events_approve', 'post' => $post_id, 'token' => $token ), admin_url( 'admin-post.php' ) );

	if ( get_option( 'cfoc_events_notify', 1 ) ) {
		wp_mail(
			get_option( 'admin_email' ),
			sprintf( '[%s] New event suggestion%s: %s', wp_specialchars_decode( get_bloginfo( 'name' ) ), $flagged ? ' (possible spam)' : '', $title ),
			sprintf(
				"A new event was suggested for the CfOC events calendar.\n\n%s\n%s – %s\n%s\n%s\n\nNotes: %s\nFrom: %s\n\nTo publish it, click this link (you may be asked to log in first):\n%s\n\nTo ignore it, do nothing.",
				$title,
				$start,
				$end ? $end : $start,
				$location,
				$url,
				$notes ? $notes : '—',
				$email ? $email : 'anonymous',
				$approve_url
			)
		);
	}

	wp_safe_redirect( add_query_arg( 'cfoc_suggest', 'thanks', $return ) . '#suggest-event' );
	exit;
}
