<?php
/**
 * Admin: list columns, Import & Sync screen, submitter meta box.
 */

defined( 'ABSPATH' ) || exit;

/* ---------- List table columns ---------- */

add_filter(
	'manage_cfoc_event_posts_columns',
	function ( $cols ) {
		$new = array();
		foreach ( $cols as $k => $v ) {
			$new[ $k ] = $v;
			if ( 'title' === $k ) {
				$new['cfoc_dates']    = __( 'Dates', 'cfoc-events' );
				$new['cfoc_location'] = __( 'Location', 'cfoc-events' );
				$new['cfoc_verified'] = __( 'Verified', 'cfoc-events' );
			}
		}
		unset( $new['date'] );
		return $new;
	}
);

add_action(
	'manage_cfoc_event_posts_custom_column',
	function ( $col, $post_id ) {
		switch ( $col ) {
			case 'cfoc_dates':
				$s = get_post_meta( $post_id, 'cfoc_start_date', true );
				$e = get_post_meta( $post_id, 'cfoc_end_date', true );
				echo esc_html( $s ? cfoc_events_format_range( $s, $e ) : '—' );
				if ( $e && $e < current_time( 'Y-m-d' ) ) {
					echo ' <span style="color:#a00">(' . esc_html__( 'past', 'cfoc-events' ) . ')</span>';
				}
				break;
			case 'cfoc_location':
				echo esc_html( get_post_meta( $post_id, 'cfoc_online', true ) ? __( 'Online', 'cfoc-events' ) : get_post_meta( $post_id, 'cfoc_location', true ) );
				break;
			case 'cfoc_verified':
				$v   = get_post_meta( $post_id, 'cfoc_last_verified', true );
				$src = get_post_meta( $post_id, 'cfoc_source_url', true );
				echo $v ? esc_html( $v ) : '—';
				if ( $src ) {
					echo ' <a href="' . esc_url( $src ) . '" target="_blank" rel="noopener">' . esc_html__( 'source', 'cfoc-events' ) . '</a>';
				}
				if ( get_post_meta( $post_id, 'cfoc_lock', true ) ) {
					echo ' 🔒';
				}
				break;
		}
	},
	10,
	2
);

add_filter(
	'manage_edit-cfoc_event_sortable_columns',
	function ( $cols ) {
		$cols['cfoc_dates'] = 'cfoc_start_date';
		return $cols;
	}
);

add_action(
	'pre_get_posts',
	function ( $q ) {
		if ( ! is_admin() || ! $q->is_main_query() || 'cfoc_event' !== $q->get( 'post_type' ) ) {
			return;
		}
		$orderby = $q->get( 'orderby' );
		if ( ! $orderby || 'cfoc_start_date' === $orderby ) {
			$q->set( 'meta_key', 'cfoc_start_date' );
			$q->set( 'orderby', 'meta_value' );
			if ( ! $q->get( 'order' ) || ! isset( $_GET['order'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				$q->set( 'order', 'ASC' );
			}
		}
	}
);

/* ---------- Submitter notes (public suggestions) ---------- */

add_action(
	'add_meta_boxes_cfoc_event',
	function ( $post ) {
		if ( get_post_meta( $post->ID, 'cfoc_submitter', true ) ) {
			add_meta_box(
				'cfoc-submitter',
				__( 'Suggestion details', 'cfoc-events' ),
				function ( $post ) {
					echo '<p>' . esc_html( get_post_meta( $post->ID, 'cfoc_submitter', true ) ) . '</p>';
					echo '<p class="description">' . esc_html__( 'Submitted through the public “Suggest an event” form. Verify against the organizer’s page, fill in the Event details panel, then publish.', 'cfoc-events' ) . '</p>';
				},
				'cfoc_event',
				'side',
				'high'
			);
		}
	}
);

/* ---------- Pending count bubble ---------- */

add_action(
	'admin_menu',
	function () {
		global $menu;
		$count = wp_count_posts( 'cfoc_event' );
		$n     = isset( $count->pending ) ? (int) $count->pending : 0;
		if ( $n && is_array( $menu ) ) {
			foreach ( $menu as $i => $item ) {
				if ( isset( $item[2] ) && 'edit.php?post_type=cfoc_event' === $item[2] ) {
					$menu[ $i ][0] .= ' <span class="awaiting-mod"><span class="pending-count">' . $n . '</span></span>'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
				}
			}
		}
	},
	99
);

/* ---------- Import & Sync screen ---------- */

add_action(
	'admin_menu',
	function () {
		add_submenu_page(
			'edit.php?post_type=cfoc_event',
			__( 'Import & Sync', 'cfoc-events' ),
			__( 'Import & Sync', 'cfoc-events' ),
			'edit_others_posts',
			'cfoc-events-sync',
			'cfoc_events_sync_screen'
		);
	}
);

add_action( 'admin_post_cfoc_events_settings', 'cfoc_events_handle_settings' );
add_action( 'admin_post_cfoc_events_import', 'cfoc_events_handle_import' );
add_action( 'admin_post_cfoc_events_sync_now', 'cfoc_events_handle_sync_now' );
add_action( 'admin_post_cfoc_events_export', 'cfoc_events_handle_export' );

function cfoc_events_admin_back( $msg ) {
	wp_safe_redirect( add_query_arg( array( 'post_type' => 'cfoc_event', 'page' => 'cfoc-events-sync', 'cfoc_msg' => rawurlencode( $msg ) ), admin_url( 'edit.php' ) ) );
	exit;
}

function cfoc_events_stats_message( $stats ) {
	$msg = sprintf(
		'%d created, %d updated, %d unchanged, %d locked, %d withdrawn.',
		(int) ( $stats['created'] ?? 0 ),
		(int) ( $stats['updated'] ?? 0 ),
		(int) ( $stats['unchanged'] ?? 0 ),
		(int) ( $stats['locked'] ?? 0 ),
		(int) ( $stats['withdrawn'] ?? 0 )
	);
	if ( ! empty( $stats['errors'] ) ) {
		$msg .= ' Errors: ' . implode( ' | ', array_slice( $stats['errors'], 0, 5 ) );
	}
	return $msg;
}

function cfoc_events_handle_settings() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'cfoc-events' ) );
	}
	check_admin_referer( 'cfoc_events_settings' );
	$url = isset( $_POST['feed_url'] ) ? esc_url_raw( trim( wp_unslash( $_POST['feed_url'] ) ) ) : '';
	update_option( 'cfoc_events_feed_url', $url );
	update_option( 'cfoc_events_autopublish', empty( $_POST['autopublish'] ) ? 0 : 1 );
	update_option( 'cfoc_events_notify', empty( $_POST['notify'] ) ? 0 : 1 );
	delete_option( 'cfoc_events_feed_hash' );
	if ( ! wp_next_scheduled( 'cfoc_events_sync' ) ) {
		wp_schedule_event( time() + MINUTE_IN_SECONDS, 'daily', 'cfoc_events_sync' );
	}
	cfoc_events_admin_back( __( 'Settings saved.', 'cfoc-events' ) );
}

function cfoc_events_handle_import() {
	if ( ! current_user_can( 'edit_others_posts' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'cfoc-events' ) );
	}
	check_admin_referer( 'cfoc_events_import' );
	$json = '';
	if ( ! empty( $_FILES['feed_file']['tmp_name'] ) && is_uploaded_file( $_FILES['feed_file']['tmp_name'] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$json = file_get_contents( $_FILES['feed_file']['tmp_name'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput, WordPress.WP.AlternativeFunctions
	} elseif ( ! empty( $_POST['feed_json'] ) ) {
		$json = wp_unslash( $_POST['feed_json'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- every field is sanitized per item in cfoc_events_clean_feed_item().
	} elseif ( ! empty( $_POST['use_bundled'] ) ) {
		$json = file_get_contents( CFOC_EVENTS_DIR . 'data/events.json' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}
	if ( '' === $json ) {
		cfoc_events_admin_back( __( 'Nothing to import — choose a file or paste JSON.', 'cfoc-events' ) );
	}
	$stats = cfoc_events_import_json( $json, array( 'source' => 'manual' ) );
	cfoc_events_admin_back( __( 'Import finished: ', 'cfoc-events' ) . cfoc_events_stats_message( $stats ) );
}

function cfoc_events_handle_sync_now() {
	if ( ! current_user_can( 'edit_others_posts' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'cfoc-events' ) );
	}
	check_admin_referer( 'cfoc_events_sync_now' );
	delete_option( 'cfoc_events_feed_hash' );
	$r = cfoc_events_run_feed_sync();
	if ( is_wp_error( $r ) ) {
		cfoc_events_admin_back( __( 'Sync failed: ', 'cfoc-events' ) . $r->get_error_message() );
	}
	cfoc_events_admin_back( __( 'Sync finished: ', 'cfoc-events' ) . cfoc_events_stats_message( $r ) );
}

function cfoc_events_handle_export() {
	if ( ! current_user_can( 'edit_others_posts' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'cfoc-events' ) );
	}
	check_admin_referer( 'cfoc_events_export' );
	nocache_headers();
	header( 'Content-Type: application/json; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename="cfoc-events-' . gmdate( 'Y-m-d' ) . '.json"' );
	echo wp_json_encode( cfoc_events_export_array(), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
	exit;
}

function cfoc_events_sync_screen() {
	$last  = get_option( 'cfoc_events_last_import' );
	$feed  = get_option( 'cfoc_events_feed_url', '' );
	$next  = wp_next_scheduled( 'cfoc_events_sync' );
	$msg   = isset( $_GET['cfoc_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['cfoc_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$ics   = rest_url( 'cfoc-events/v1/ics' );
	$count = wp_count_posts( 'cfoc_event' );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Industry Events — Import & Sync', 'cfoc-events' ); ?></h1>
		<?php if ( $msg ) : ?>
			<div class="notice notice-info is-dismissible"><p><?php echo esc_html( $msg ); ?></p></div>
		<?php endif; ?>

		<p>
			<?php
			printf(
				/* translators: 1: published count 2: pending count */
				esc_html__( '%1$d published · %2$d pending review', 'cfoc-events' ),
				(int) $count->publish,
				(int) $count->pending
			);
			?>
			&nbsp;·&nbsp; <a href="<?php echo esc_url( admin_url( 'edit.php?post_status=pending&post_type=cfoc_event' ) ); ?>"><?php esc_html_e( 'Review pending', 'cfoc-events' ); ?></a>
		</p>

		<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:20px;max-width:1200px">
			<div class="card" style="max-width:none">
				<h2><?php esc_html_e( 'Automatic feed sync', 'cfoc-events' ); ?></h2>
				<p><?php esc_html_e( 'Once a day WordPress fetches the events feed below and adds or updates events automatically. Events whose dates are not yet confirmed by the organizer are published with a small “Dates unconfirmed” tag. Events you lock are never overwritten.', 'cfoc-events' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="cfoc_events_settings">
					<?php wp_nonce_field( 'cfoc_events_settings' ); ?>
					<p><label for="cfoc-feed-url"><strong><?php esc_html_e( 'Feed URL (JSON)', 'cfoc-events' ); ?></strong></label><br>
					<input id="cfoc-feed-url" type="url" name="feed_url" value="<?php echo esc_attr( $feed ); ?>" class="large-text" placeholder="https://raw.githubusercontent.com/…/events.json"></p>
					<p><label><input type="checkbox" name="autopublish" value="1" <?php checked( get_option( 'cfoc_events_autopublish', 1 ) ); ?>> <?php esc_html_e( 'Publish feed events automatically (recommended)', 'cfoc-events' ); ?></label></p>
					<p><label><input type="checkbox" name="notify" value="1" <?php checked( get_option( 'cfoc_events_notify', 1 ) ); ?>> <?php esc_html_e( 'Email the site admin when someone suggests an event', 'cfoc-events' ); ?></label></p>
					<?php submit_button( __( 'Save settings', 'cfoc-events' ), 'primary', 'submit', false ); ?>
				</form>
				<?php if ( $feed ) : ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:12px">
						<input type="hidden" name="action" value="cfoc_events_sync_now">
						<?php wp_nonce_field( 'cfoc_events_sync_now' ); ?>
						<?php submit_button( __( 'Sync now', 'cfoc-events' ), 'secondary', 'submit', false ); ?>
						<?php if ( $next ) : ?>
							<span class="description" style="margin-left:8px"><?php echo esc_html( sprintf( __( 'Next automatic sync: %s', 'cfoc-events' ), wp_date( 'M j, Y g:i a', $next ) ) ); ?></span>
						<?php endif; ?>
					</form>
				<?php endif; ?>
			</div>

			<div class="card" style="max-width:none">
				<h2><?php esc_html_e( 'Import a file', 'cfoc-events' ); ?></h2>
				<p><?php esc_html_e( 'Upload an events.json file (for example, the updated list delivered by the weekly research run), or paste its contents.', 'cfoc-events' ); ?></p>
				<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="cfoc_events_import">
					<?php wp_nonce_field( 'cfoc_events_import' ); ?>
					<p><input type="file" name="feed_file" accept=".json,application/json"></p>
					<p><textarea name="feed_json" rows="5" class="large-text code" placeholder='{"version":1,"events":[…]}'></textarea></p>
					<p>
						<?php submit_button( __( 'Import', 'cfoc-events' ), 'primary', 'submit', false ); ?>
						<button type="submit" name="use_bundled" value="1" class="button"><?php esc_html_e( 'Re-import bundled list', 'cfoc-events' ); ?></button>
					</p>
				</form>
			</div>

			<div class="card" style="max-width:none">
				<h2><?php esc_html_e( 'Export & subscribe', 'cfoc-events' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="cfoc_events_export">
					<?php wp_nonce_field( 'cfoc_events_export' ); ?>
					<?php submit_button( __( 'Download events.json', 'cfoc-events' ), 'secondary', 'submit', false ); ?>
				</form>
				<p><strong><?php esc_html_e( 'Public calendar feed (.ics):', 'cfoc-events' ); ?></strong><br><code style="word-break:break-all"><?php echo esc_html( $ics ); ?></code></p>
				<p><strong><?php esc_html_e( 'Public JSON:', 'cfoc-events' ); ?></strong><br><code style="word-break:break-all"><?php echo esc_html( rest_url( 'cfoc-events/v1/events' ) ); ?></code></p>
				<p class="description"><?php esc_html_e( 'To show the calendar on a page, add the “Industry Events Calendar” block (and optionally the “Suggest an Industry Event” block) in the block editor.', 'cfoc-events' ); ?></p>
			</div>
		</div>

		<?php if ( $last ) : ?>
			<h2><?php esc_html_e( 'Last import', 'cfoc-events' ); ?></h2>
			<p><?php echo esc_html( wp_date( 'M j, Y g:i a', (int) $last['time'] ) . ' (' . $last['source'] . ') — ' . cfoc_events_stats_message( $last['stats'] ) ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

/* ---------- One-click approve for suggested events ---------- */

add_filter(
	'post_row_actions',
	function ( $actions, $post ) {
		if ( 'cfoc_event' === $post->post_type && 'pending' === $post->post_status && current_user_can( 'publish_post', $post->ID ) ) {
			$url     = wp_nonce_url( admin_url( 'admin-post.php?action=cfoc_events_approve&post=' . $post->ID ), 'cfoc_approve_' . $post->ID );
			$actions = array( 'cfoc_approve' => '<a href="' . esc_url( $url ) . '" style="font-weight:600">' . esc_html__( 'Approve & publish', 'cfoc-events' ) . '</a>' ) + $actions;
		}
		return $actions;
	},
	10,
	2
);

add_action( 'admin_post_cfoc_events_approve', 'cfoc_events_handle_approve' );
add_action( 'admin_post_nopriv_cfoc_events_approve', 'auth_redirect' ); // Not logged in: log in, then come back to the link.

function cfoc_events_handle_approve() {
	$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
	$token   = isset( $_GET['token'] ) ? sanitize_text_field( wp_unslash( $_GET['token'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! $post_id || 'cfoc_event' !== get_post_type( $post_id ) || ! current_user_can( 'publish_post', $post_id ) ) {
		wp_die( esc_html__( 'You are not allowed to approve this event.', 'cfoc-events' ) );
	}
	$stored  = get_post_meta( $post_id, '_cfoc_approve_token', true );
	$byemail = $token && $stored && hash_equals( $stored, $token );
	if ( ! $byemail ) {
		check_admin_referer( 'cfoc_approve_' . $post_id );
	}
	wp_update_post(
		array(
			'ID'            => $post_id,
			'post_status'   => 'publish',
			'post_date'     => current_time( 'mysql' ),
			'post_date_gmt' => current_time( 'mysql', true ),
		)
	);
	delete_post_meta( $post_id, '_cfoc_approve_token' );
	cfoc_events_bust_cache();
	if ( $byemail ) {
		wp_die(
			'<p>' . esc_html( sprintf( __( '“%s” is now published on the events calendar.', 'cfoc-events' ), get_the_title( $post_id ) ) ) . '</p><p><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Go to the site', 'cfoc-events' ) . '</a></p>',
			esc_html__( 'Event approved', 'cfoc-events' ),
			array( 'response' => 200 )
		);
	}
	wp_safe_redirect( add_query_arg( array( 'post_type' => 'cfoc_event', 'post_status' => 'pending' ), admin_url( 'edit.php' ) ) );
	exit;
}
