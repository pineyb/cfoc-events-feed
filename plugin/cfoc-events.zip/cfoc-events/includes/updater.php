<?php
/**
 * Self-updates from the cfoc-events-feed GitHub repository, so plugin fixes
 * arrive like any other WordPress plugin update (and install automatically).
 */

defined( 'ABSPATH' ) || exit;

define( 'CFOC_EVENTS_UPDATE_INFO', 'https://raw.githubusercontent.com/pineyb/cfoc-events-feed/main/plugin/info.json' );

function cfoc_events_remote_info( $force = false ) {
	$cached = get_site_transient( 'cfoc_events_remote_info' );
	if ( false !== $cached && ! $force ) {
		return $cached;
	}
	$res  = wp_remote_get( CFOC_EVENTS_UPDATE_INFO, array( 'timeout' => 10 ) );
	$info = null;
	if ( ! is_wp_error( $res ) && 200 === (int) wp_remote_retrieve_response_code( $res ) ) {
		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( is_array( $data ) && ! empty( $data['version'] ) && ! empty( $data['download_url'] ) ) {
			$info = $data;
		}
	}
	set_site_transient( 'cfoc_events_remote_info', $info ? $info : array(), 6 * HOUR_IN_SECONDS );
	return $info;
}

add_filter(
	'pre_set_site_transient_update_plugins',
	function ( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$info   = cfoc_events_remote_info();
		$plugin = plugin_basename( CFOC_EVENTS_FILE );
		if ( $info && version_compare( $info['version'], CFOC_EVENTS_VERSION, '>' ) ) {
			$transient->response[ $plugin ] = (object) array(
				'id'          => $plugin,
				'slug'        => 'cfoc-events',
				'plugin'      => $plugin,
				'new_version' => $info['version'],
				'package'     => $info['download_url'],
				'url'         => 'https://github.com/pineyb/cfoc-events-feed',
				'tested'      => isset( $info['tested'] ) ? $info['tested'] : '',
				'requires'    => isset( $info['requires'] ) ? $info['requires'] : '',
			);
		} else {
			$transient->no_update[ $plugin ] = (object) array(
				'id'          => $plugin,
				'slug'        => 'cfoc-events',
				'plugin'      => $plugin,
				'new_version' => CFOC_EVENTS_VERSION,
				'url'         => 'https://github.com/pineyb/cfoc-events-feed',
				'package'     => '',
			);
		}
		return $transient;
	}
);

// "View details" popup in the Plugins screen.
add_filter(
	'plugins_api',
	function ( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || 'cfoc-events' !== $args->slug ) {
			return $result;
		}
		$info = cfoc_events_remote_info();
		return (object) array(
			'name'          => 'CfOC Industry Events',
			'slug'          => 'cfoc-events',
			'version'       => $info ? $info['version'] : CFOC_EVENTS_VERSION,
			'author'        => 'Center for Offsite Construction',
			'homepage'      => 'https://github.com/pineyb/cfoc-events-feed',
			'download_link' => $info ? $info['download_url'] : '',
			'sections'      => array(
				'description' => 'Offsite construction industry events calendar for the Center for Offsite Construction.',
				'changelog'   => $info && ! empty( $info['changelog'] ) ? wp_kses_post( $info['changelog'] ) : '',
			),
		);
	},
	10,
	3
);

// Install this plugin's updates automatically (WordPress checks twice a day).
add_filter(
	'auto_update_plugin',
	function ( $update, $item ) {
		if ( isset( $item->plugin ) && plugin_basename( CFOC_EVENTS_FILE ) === $item->plugin ) {
			return (bool) get_option( 'cfoc_events_autoupdate', 1 );
		}
		return $update;
	},
	10,
	2
);
