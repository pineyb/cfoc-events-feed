<?php
/**
 * Fetching and normalizing events.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Return published events as plain arrays, sorted by start date.
 *
 * @param array $args { from?: 'YYYY-MM-DD' (events ending on/after), to?: 'YYYY-MM-DD' (starting on/before), type?: slug }
 */
function cfoc_events_get( $args = array() ) {
	$args      = wp_parse_args( $args, array( 'from' => '', 'to' => '', 'type' => '' ) );
	$cache_key = 'cfoc_events_' . md5( wp_json_encode( $args ) . get_option( 'cfoc_events_cache_bust', 0 ) );
	$cached    = get_transient( $cache_key );
	if ( false !== $cached ) {
		return $cached;
	}

	$meta_query = array( 'relation' => 'AND' );
	if ( $args['from'] ) {
		$meta_query[] = array(
			'key'     => 'cfoc_end_date',
			'value'   => $args['from'],
			'compare' => '>=',
			'type'    => 'CHAR',
		);
	}
	if ( $args['to'] ) {
		$meta_query[] = array(
			'key'     => 'cfoc_start_date',
			'value'   => $args['to'],
			'compare' => '<=',
			'type'    => 'CHAR',
		);
	}

	$q = array(
		'post_type'      => 'cfoc_event',
		'post_status'    => 'publish',
		'posts_per_page' => 500,
		'no_found_rows'  => true,
		'meta_key'       => 'cfoc_start_date', // phpcs:ignore WordPress.DB.SlowDBQuery
		'orderby'        => 'meta_value',
		'order'          => 'ASC',
		'meta_query'     => $meta_query, // phpcs:ignore WordPress.DB.SlowDBQuery
	);
	if ( $args['type'] ) {
		$q['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery
			array(
				'taxonomy' => 'cfoc_event_type',
				'field'    => 'slug',
				'terms'    => $args['type'],
			),
		);
	}

	$events = array();
	foreach ( get_posts( $q ) as $post ) {
		$e = cfoc_events_normalize( $post );
		if ( $e['start'] ) {
			$events[] = $e;
		}
	}

	set_transient( $cache_key, $events, 12 * HOUR_IN_SECONDS );
	return $events;
}

function cfoc_events_normalize( $post ) {
	$post  = get_post( $post );
	$m     = function ( $k ) use ( $post ) {
		return get_post_meta( $post->ID, $k, true );
	};
	$start = $m( 'cfoc_start_date' );
	$end   = $m( 'cfoc_end_date' );
	if ( ! $end || $end < $start ) {
		$end = $start;
	}
	$types = wp_get_post_terms( $post->ID, 'cfoc_event_type', array( 'fields' => 'names' ) );
	$desc  = has_excerpt( $post ) ? get_the_excerpt( $post ) : wp_trim_words( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ), 40 );

	return array(
		'id'           => $post->ID,
		'title'        => html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ),
		'start'        => $start,
		'end'          => $end,
		'location'     => (string) $m( 'cfoc_location' ),
		'venue'        => (string) $m( 'cfoc_venue' ),
		'organizer'    => (string) $m( 'cfoc_organizer' ),
		'url'          => (string) $m( 'cfoc_event_url' ),
		'region'       => (string) $m( 'cfoc_region' ),
		'online'       => (bool) $m( 'cfoc_online' ),
		'unconfirmed'  => (bool) $m( 'cfoc_unconfirmed' ),
		'people'       => json_decode( (string) $m( 'cfoc_people' ), true ) ?: array(),
		'type'         => is_wp_error( $types ) || empty( $types ) ? '' : $types[0],
		'types'        => is_wp_error( $types ) ? array() : $types,
		'description'  => html_entity_decode( $desc, ENT_QUOTES, 'UTF-8' ),
		'lastVerified' => (string) $m( 'cfoc_last_verified' ),
		'permalink'    => get_permalink( $post ),
	);
}

/**
 * Bust the cache whenever an event changes.
 */
function cfoc_events_bust_cache() {
	update_option( 'cfoc_events_cache_bust', time(), false );
}
add_action( 'save_post_cfoc_event', 'cfoc_events_bust_cache' );
add_action( 'rest_after_insert_cfoc_event', 'cfoc_events_bust_cache' );
add_action( 'deleted_post', 'cfoc_events_bust_cache' );
add_action( 'trashed_post', 'cfoc_events_bust_cache' );
add_action( 'set_object_terms', 'cfoc_events_bust_cache' );
add_action( 'updated_post_meta', 'cfoc_events_maybe_bust_meta', 10, 2 );
add_action( 'added_post_meta', 'cfoc_events_maybe_bust_meta', 10, 2 );

function cfoc_events_maybe_bust_meta( $meta_id, $object_id ) {
	if ( 'cfoc_event' === get_post_type( $object_id ) ) {
		cfoc_events_bust_cache();
	}
}

/**
 * Human date range, e.g. "Apr 5–8, 2027" or "Jan 30 – Feb 2, 2027".
 */
function cfoc_events_format_range( $start, $end ) {
	$s = strtotime( $start );
	$e = strtotime( $end ? $end : $start );
	if ( ! $s ) {
		return '';
	}
	if ( $s === $e ) {
		return wp_date( 'M j, Y', $s, new DateTimeZone( 'UTC' ) );
	}
	$utc = new DateTimeZone( 'UTC' );
	if ( gmdate( 'Y-m', $s ) === gmdate( 'Y-m', $e ) ) {
		return wp_date( 'M j', $s, $utc ) . '–' . wp_date( 'j, Y', $e, $utc );
	}
	if ( gmdate( 'Y', $s ) === gmdate( 'Y', $e ) ) {
		return wp_date( 'M j', $s, $utc ) . ' – ' . wp_date( 'M j, Y', $e, $utc );
	}
	return wp_date( 'M j, Y', $s, $utc ) . ' – ' . wp_date( 'M j, Y', $e, $utc );
}
