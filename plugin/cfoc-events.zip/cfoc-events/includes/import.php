<?php
/**
 * JSON import, feed sync (WP-Cron) and export.
 *
 * Feed format (data/events.json is an example):
 * {
 *   "version": 1,
 *   "generated": "2026-11-15",
 *   "events": [
 *     {
 *       "id": "mbi-world-of-modular-2027",      // stable ID used to match on later syncs
 *       "title": "World of Modular 2027",
 *       "start": "2027-04-05", "end": "2027-04-08",
 *       "location": "Orlando, FL", "venue": "Rosen Shingle Creek",
 *       "organizer": "Modular Building Institute",
 *       "url": "https://…",                      // official event page
 *       "type": "Conference", "region": "North America", "online": false,
 *       "description": "…",
 *       "source_url": "https://…", "last_verified": "2026-11-15",
 *       "status": "confirmed" | "unconfirmed" | "cancelled"
 *     }
 *   ]
 * }
 */

defined( 'ABSPATH' ) || exit;

add_action( 'cfoc_events_sync', 'cfoc_events_run_feed_sync' );
add_action( 'cfoc_events_sync', 'cfoc_events_maybe_import_bundled' );
add_action( 'admin_init', 'cfoc_events_maybe_import_bundled' );

/**
 * When data/events.json inside the plugin changes (e.g. the twice-weekly research run
 * writes a new one), import it once automatically.
 */
function cfoc_events_maybe_import_bundled() {
	$file = CFOC_EVENTS_DIR . 'data/events.json';
	if ( ! file_exists( $file ) || ! get_option( 'cfoc_events_seeded' ) ) {
		return;
	}
	$hash = md5_file( $file );
	if ( get_option( 'cfoc_events_bundled_hash' ) === $hash ) {
		return;
	}
	update_option( 'cfoc_events_bundled_hash', $hash, false );
	cfoc_events_import_json( file_get_contents( $file ), array( 'source' => 'bundled file' ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
}

/**
 * Import a feed JSON string. Returns stats array.
 */
function cfoc_events_import_json( $json, $opts = array() ) {
	$opts  = wp_parse_args( $opts, array( 'source' => 'manual' ) );
	$stats = array(
		'created'   => 0,
		'updated'   => 0,
		'unchanged' => 0,
		'locked'    => 0,
		'withdrawn' => 0,
		'errors'    => array(),
	);

	$data = json_decode( (string) $json, true );
	if ( ! is_array( $data ) ) {
		$stats['errors'][] = 'Not valid JSON.';
		return $stats;
	}
	$items = isset( $data['events'] ) && is_array( $data['events'] ) ? $data['events'] : ( isset( $data[0] ) ? $data : array() );
	if ( ! $items ) {
		$stats['errors'][] = 'No "events" array found.';
		return $stats;
	}

	cfoc_events_seed_default_types();
	$auto_publish = (bool) get_option( 'cfoc_events_autopublish', 1 );

	foreach ( $items as $i => $raw ) {
		$e = cfoc_events_clean_feed_item( $raw );
		if ( is_wp_error( $e ) ) {
			$stats['errors'][] = sprintf( 'Item %d: %s', $i + 1, $e->get_error_message() );
			continue;
		}

		$existing = cfoc_events_find_existing( $e );

		if ( $existing ) {
			if ( get_post_meta( $existing->ID, 'cfoc_lock', true ) ) {
				$stats['locked']++;
				continue;
			}
			if ( 'cancelled' === $e['status'] ) {
				if ( 'draft' !== $existing->post_status ) {
					wp_update_post( array( 'ID' => $existing->ID, 'post_status' => 'draft' ) );
					update_post_meta( $existing->ID, 'cfoc_last_verified', $e['last_verified'] );
					$stats['withdrawn']++;
				} else {
					$stats['unchanged']++;
				}
				continue;
			}
			$changed = cfoc_events_apply( $existing->ID, $e, false );
			// Anything the feed lists goes live; unconfirmed items carry an "unconfirmed" flag instead of waiting for review.
			if ( 'pending' === $existing->post_status && $auto_publish ) {
				wp_update_post( array( 'ID' => $existing->ID, 'post_status' => 'publish' ) );
				$changed = true;
			}
			$changed ? $stats['updated']++ : $stats['unchanged']++;
			continue;
		}

		if ( 'cancelled' === $e['status'] ) {
			continue;
		}

		$status  = $auto_publish ? 'publish' : 'pending';
		$post_id = wp_insert_post(
			array(
				'post_type'    => 'cfoc_event',
				'post_status'  => $status,
				'post_title'   => $e['title'],
				'post_excerpt' => $e['description'],
				'post_content' => $e['description'] ? "<!-- wp:paragraph -->\n<p>" . esc_html( $e['description'] ) . "</p>\n<!-- /wp:paragraph -->" : '',
			),
			true
		);
		if ( is_wp_error( $post_id ) ) {
			$stats['errors'][] = $e['title'] . ': ' . $post_id->get_error_message();
			continue;
		}
		cfoc_events_apply( $post_id, $e, true );
		$stats['created']++;
	}

	if ( ! empty( $data['generated'] ) ) {
		$gen = cfoc_events_sanitize_meta_date( $data['generated'] );
		if ( $gen ) {
			update_option( 'cfoc_events_last_verified_run', $gen, false );
		}
	}

	cfoc_events_bust_cache();
	update_option(
		'cfoc_events_last_import',
		array(
			'time'   => time(),
			'source' => $opts['source'],
			'stats'  => $stats,
		),
		false
	);

	return $stats;
}

function cfoc_events_clean_feed_item( $raw ) {
	if ( ! is_array( $raw ) ) {
		return new WP_Error( 'bad', 'Not an object.' );
	}
	$g = function ( $k, $d = '' ) use ( $raw ) {
		return isset( $raw[ $k ] ) ? $raw[ $k ] : $d;
	};

	$e = array(
		'id'            => sanitize_title( (string) $g( 'id' ) ),
		'title'         => sanitize_text_field( (string) $g( 'title' ) ),
		'start'         => cfoc_events_sanitize_meta_date( (string) $g( 'start' ) ),
		'end'           => cfoc_events_sanitize_meta_date( (string) $g( 'end' ) ),
		'location'      => sanitize_text_field( (string) $g( 'location' ) ),
		'venue'         => sanitize_text_field( (string) $g( 'venue' ) ),
		'organizer'     => sanitize_text_field( (string) $g( 'organizer' ) ),
		'url'           => esc_url_raw( (string) $g( 'url' ) ),
		'type'          => sanitize_text_field( (string) $g( 'type' ) ),
		'region'        => sanitize_text_field( (string) $g( 'region' ) ),
		'online'        => (bool) $g( 'online', false ),
		'description'   => sanitize_textarea_field( (string) $g( 'description' ) ),
		'source_url'    => esc_url_raw( (string) $g( 'source_url' ) ),
		'last_verified' => cfoc_events_sanitize_meta_date( (string) $g( 'last_verified' ) ),
		'people'        => cfoc_events_sanitize_people( $g( 'cfoc_people', array() ) ),
		'status'        => in_array( $g( 'status', 'confirmed' ), array( 'confirmed', 'unconfirmed', 'cancelled' ), true ) ? $g( 'status', 'confirmed' ) : 'unconfirmed',
	);

	if ( '' === $e['title'] ) {
		return new WP_Error( 'bad', 'Missing title.' );
	}
	if ( '' === $e['start'] ) {
		return new WP_Error( 'bad', 'Missing or invalid start date for "' . $e['title'] . '".' );
	}
	if ( ! $e['end'] || $e['end'] < $e['start'] ) {
		$e['end'] = $e['start'];
	}
	if ( '' === $e['id'] ) {
		$e['id'] = sanitize_title( $e['title'] . '-' . substr( $e['start'], 0, 4 ) );
	}
	return $e;
}

function cfoc_events_find_existing( $e ) {
	$found = get_posts(
		array(
			'post_type'      => 'cfoc_event',
			'post_status'    => array( 'publish', 'pending', 'draft', 'future', 'private' ),
			'posts_per_page' => 1,
			'meta_key'       => 'cfoc_external_id', // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => $e['id'], // phpcs:ignore WordPress.DB.SlowDBQuery
		)
	);
	if ( $found ) {
		return $found[0];
	}
	// Fallback: same title + same start date, created by hand before the feed knew about it.
	$candidates = get_posts(
		array(
			'post_type'      => 'cfoc_event',
			'post_status'    => array( 'publish', 'pending', 'draft', 'future', 'private' ),
			'posts_per_page' => 5,
			'title'          => $e['title'],
			'meta_key'       => 'cfoc_start_date', // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => $e['start'], // phpcs:ignore WordPress.DB.SlowDBQuery
		)
	);
	return $candidates ? $candidates[0] : null;
}

/**
 * Write feed values onto a post. Returns true if anything changed.
 */
function cfoc_events_apply( $post_id, $e, $is_new ) {
	$changed = false;
	$map     = array(
		'cfoc_external_id'   => $e['id'],
		'cfoc_start_date'    => $e['start'],
		'cfoc_end_date'      => $e['end'],
		'cfoc_location'      => $e['location'],
		'cfoc_venue'         => $e['venue'],
		'cfoc_organizer'     => $e['organizer'],
		'cfoc_event_url'     => $e['url'],
		'cfoc_region'        => $e['region'],
		'cfoc_online'        => $e['online'] ? '1' : '',
		'cfoc_source_url'    => $e['source_url'],
		'cfoc_last_verified' => $e['last_verified'],
		'cfoc_unconfirmed'   => 'unconfirmed' === $e['status'] ? '1' : '',
		'cfoc_people'        => $e['people'],
	);
	foreach ( $map as $k => $v ) {
		if ( (string) get_post_meta( $post_id, $k, true ) !== (string) $v ) {
			update_post_meta( $post_id, $k, wp_slash( $v ) );
			if ( 'cfoc_last_verified' !== $k ) {
				$changed = true;
			}
		}
	}

	if ( ! $is_new ) {
		$post   = get_post( $post_id );
		$update = array( 'ID' => $post_id );
		if ( $post->post_title !== $e['title'] ) {
			$update['post_title'] = $e['title'];
		}
		if ( $e['description'] && $post->post_excerpt !== $e['description'] ) {
			$update['post_excerpt'] = $e['description'];
		}
		if ( count( $update ) > 1 ) {
			wp_update_post( $update );
			$changed = true;
		}
	}

	if ( $e['type'] ) {
		$term = term_exists( $e['type'], 'cfoc_event_type' );
		if ( ! $term ) {
			$term = wp_insert_term( $e['type'], 'cfoc_event_type' );
		}
		if ( ! is_wp_error( $term ) ) {
			$term_id = (int) ( is_array( $term ) ? $term['term_id'] : $term );
			$current = wp_get_object_terms( $post_id, 'cfoc_event_type', array( 'fields' => 'ids' ) );
			if ( $is_new || empty( $current ) ) {
				wp_set_object_terms( $post_id, array( $term_id ), 'cfoc_event_type' );
				$changed = $changed || ! $is_new;
			}
		}
	}
	return $changed;
}

/**
 * Fetch the configured feed URL and import it. Runs daily via WP-Cron.
 */
function cfoc_events_run_feed_sync() {
	$url = get_option( 'cfoc_events_feed_url', '' );
	if ( ! $url ) {
		return new WP_Error( 'no_feed', 'No feed URL configured.' );
	}
	$res = wp_remote_get( $url, array( 'timeout' => 20, 'headers' => array( 'Accept' => 'application/json' ) ) );
	if ( is_wp_error( $res ) ) {
		update_option( 'cfoc_events_last_import', array( 'time' => time(), 'source' => 'feed', 'stats' => array( 'errors' => array( $res->get_error_message() ) ) ), false );
		return $res;
	}
	$code = wp_remote_retrieve_response_code( $res );
	if ( 200 !== (int) $code ) {
		$err = new WP_Error( 'http', 'Feed returned HTTP ' . $code );
		update_option( 'cfoc_events_last_import', array( 'time' => time(), 'source' => 'feed', 'stats' => array( 'errors' => array( $err->get_error_message() ) ) ), false );
		return $err;
	}
	$body = wp_remote_retrieve_body( $res );
	$hash = md5( $body . CFOC_EVENTS_VERSION ); // Re-import once after a plugin update.
	if ( get_option( 'cfoc_events_feed_hash' ) === $hash ) {
		return array( 'unchanged_feed' => true );
	}
	$stats = cfoc_events_import_json( $body, array( 'source' => 'feed' ) );
	if ( empty( $stats['errors'] ) || ( $stats['created'] + $stats['updated'] + $stats['unchanged'] ) > 0 ) {
		update_option( 'cfoc_events_feed_hash', $hash, false );
	}
	return $stats;
}

/**
 * All events in feed format (for backup / round-tripping).
 */
function cfoc_events_export_array() {
	$posts = get_posts(
		array(
			'post_type'      => 'cfoc_event',
			'post_status'    => array( 'publish', 'pending' ),
			'posts_per_page' => -1,
			'meta_key'       => 'cfoc_start_date', // phpcs:ignore WordPress.DB.SlowDBQuery
			'orderby'        => 'meta_value',
			'order'          => 'ASC',
		)
	);
	$out   = array();
	foreach ( $posts as $p ) {
		$n     = cfoc_events_normalize( $p );
		$out[] = array(
			'id'            => get_post_meta( $p->ID, 'cfoc_external_id', true ) ? get_post_meta( $p->ID, 'cfoc_external_id', true ) : sanitize_title( $n['title'] . '-' . substr( $n['start'], 0, 4 ) ),
			'title'         => $n['title'],
			'start'         => $n['start'],
			'end'           => $n['end'],
			'location'      => $n['location'],
			'venue'         => $n['venue'],
			'organizer'     => $n['organizer'],
			'url'           => $n['url'],
			'type'          => $n['type'],
			'region'        => $n['region'],
			'online'        => $n['online'],
			'description'   => has_excerpt( $p ) ? $p->post_excerpt : '',
			'source_url'    => get_post_meta( $p->ID, 'cfoc_source_url', true ),
			'last_verified' => $n['lastVerified'],
			'cfoc_people'   => $n['people'],
			'status'        => ( 'publish' === $p->post_status && ! get_post_meta( $p->ID, 'cfoc_unconfirmed', true ) ) ? 'confirmed' : 'unconfirmed',
		);
	}
	return array(
		'version'   => 1,
		'generated' => current_time( 'Y-m-d' ),
		'events'    => $out,
	);
}
