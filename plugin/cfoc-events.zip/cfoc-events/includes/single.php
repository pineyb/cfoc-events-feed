<?php
/**
 * Single event pages: prepend a details box to the content so any theme
 * (including block themes like TT3) shows dates, location and the official link.
 */

defined( 'ABSPATH' ) || exit;

add_filter(
	'the_content',
	function ( $content ) {
		if ( ! is_singular( 'cfoc_event' ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}
		wp_enqueue_style( 'cfoc-events-style' );
		$e    = cfoc_events_normalize( get_the_ID() );
		$rows = array(
			__( 'Dates', 'cfoc-events' )     => cfoc_events_format_range( $e['start'], $e['end'] ),
			__( 'Location', 'cfoc-events' )  => $e['online'] ? __( 'Online', 'cfoc-events' ) : $e['location'],
			__( 'Venue', 'cfoc-events' )     => $e['venue'],
			__( 'Organizer', 'cfoc-events' ) => $e['organizer'],
			__( 'Type', 'cfoc-events' )      => implode( ', ', $e['types'] ),
		);
		$html = '<div class="cfoc-events"><div class="cfoc-events__panel"><div class="cfoc-events__modal"><dl class="cfoc-events__d-list">';
		foreach ( $rows as $label => $value ) {
			if ( $value ) {
				$html .= '<dt>' . esc_html( $label ) . '</dt><dd>' . esc_html( $value ) . '</dd>';
			}
		}
		$html .= '</dl><div class="cfoc-events__d-actions">';
		if ( $e['url'] ) {
			$html .= '<a class="cfoc-events__action" href="' . esc_url( $e['url'] ) . '" target="_blank" rel="noopener">' . esc_html__( 'Official event page ↗', 'cfoc-events' ) . '</a>';
		}
		$html .= '</div>';
		if ( $e['lastVerified'] ) {
			/* translators: %s: date */
			$html .= '<p class="cfoc-events__meta" style="margin-top:14px">' . esc_html( sprintf( __( 'Details last verified %s. Always confirm with the organizer.', 'cfoc-events' ), cfoc_events_format_range( $e['lastVerified'], $e['lastVerified'] ) ) ) . '</p>';
		}
		$html .= '</div></div></div>';
		return $html . $content;
	},
	5
);
