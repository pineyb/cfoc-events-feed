<?php
/**
 * Event post type, event type taxonomy, and event meta fields.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', 'cfoc_events_register_post_type' );
add_action( 'init', 'cfoc_events_register_taxonomy' );
add_action( 'init', 'cfoc_events_register_meta' );

function cfoc_events_register_post_type() {
	register_post_type(
		'cfoc_event',
		array(
			'labels'        => array(
				'name'               => __( 'Industry Events', 'cfoc-events' ),
				'singular_name'      => __( 'Event', 'cfoc-events' ),
				'menu_name'          => __( 'Industry Events', 'cfoc-events' ),
				'add_new'            => __( 'Add Event', 'cfoc-events' ),
				'add_new_item'       => __( 'Add New Event', 'cfoc-events' ),
				'edit_item'          => __( 'Edit Event', 'cfoc-events' ),
				'new_item'           => __( 'New Event', 'cfoc-events' ),
				'view_item'          => __( 'View Event', 'cfoc-events' ),
				'search_items'       => __( 'Search Events', 'cfoc-events' ),
				'not_found'          => __( 'No events found', 'cfoc-events' ),
				'not_found_in_trash' => __( 'No events in Trash', 'cfoc-events' ),
				'all_items'          => __( 'All Events', 'cfoc-events' ),
			),
			'public'        => true,
			'has_archive'   => false,
			'show_in_rest'  => true,
			'menu_icon'     => 'dashicons-calendar-alt',
			'menu_position' => 21,
			'rewrite'       => array( 'slug' => 'industry-events' ),
			'supports'      => array( 'title', 'editor', 'excerpt', 'custom-fields', 'revisions' ),
			'template'      => array(
				array( 'core/paragraph', array( 'placeholder' => __( 'Short neutral description of the event (what it is, who it is for)…', 'cfoc-events' ) ) ),
			),
		)
	);
}

function cfoc_events_register_taxonomy() {
	register_taxonomy(
		'cfoc_event_type',
		'cfoc_event',
		array(
			'labels'            => array(
				'name'          => __( 'Event Types', 'cfoc-events' ),
				'singular_name' => __( 'Event Type', 'cfoc-events' ),
				'add_new_item'  => __( 'Add Event Type', 'cfoc-events' ),
			),
			'public'            => true,
			'hierarchical'      => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'industry-event-type' ),
		)
	);
}

function cfoc_events_default_types() {
	return array( 'Conference', 'Trade Show', 'Summit', 'Standards', 'Education', 'Policy', 'Workshop', 'Webinar' );
}

function cfoc_events_seed_default_types() {
	foreach ( cfoc_events_default_types() as $type ) {
		if ( ! term_exists( $type, 'cfoc_event_type' ) ) {
			wp_insert_term( $type, 'cfoc_event_type' );
		}
	}
}

/**
 * Meta schema. Keys are stored with a `cfoc_` prefix.
 */
function cfoc_events_meta_fields() {
	return array(
		'cfoc_start_date'    => array( 'type' => 'string', 'label' => 'Start date' ),
		'cfoc_end_date'      => array( 'type' => 'string', 'label' => 'End date' ),
		'cfoc_location'      => array( 'type' => 'string', 'label' => 'City / location' ),
		'cfoc_venue'         => array( 'type' => 'string', 'label' => 'Venue' ),
		'cfoc_organizer'     => array( 'type' => 'string', 'label' => 'Organizer' ),
		'cfoc_event_url'     => array( 'type' => 'string', 'label' => 'Official event page' ),
		'cfoc_region'        => array( 'type' => 'string', 'label' => 'Region' ),
		'cfoc_online'        => array( 'type' => 'boolean', 'label' => 'Online event' ),
		'cfoc_source_url'    => array( 'type' => 'string', 'label' => 'Verification source' ),
		'cfoc_last_verified' => array( 'type' => 'string', 'label' => 'Last verified' ),
		'cfoc_external_id'   => array( 'type' => 'string', 'label' => 'Feed ID' ),
		'cfoc_lock'          => array( 'type' => 'boolean', 'label' => 'Lock from feed updates' ),
		'cfoc_unconfirmed'   => array( 'type' => 'boolean', 'label' => 'Dates not yet confirmed by organizer' ),
		'cfoc_people'        => array( 'type' => 'string', 'label' => 'CfOC people involved (JSON)' ),
		'cfoc_submitter'     => array( 'type' => 'string', 'label' => 'Suggested by' ),
	);
}

function cfoc_events_register_meta() {
	foreach ( cfoc_events_meta_fields() as $key => $def ) {
		$private = in_array( $key, array( 'cfoc_submitter' ), true );
		register_post_meta(
			'cfoc_event',
			$key,
			array(
				'type'              => $def['type'],
				'single'            => true,
				'show_in_rest'      => ! $private,
				'default'           => 'boolean' === $def['type'] ? false : '',
				'sanitize_callback' => 'boolean' === $def['type'] ? 'rest_sanitize_boolean' : ( 'cfoc_people' === $key ? 'cfoc_events_sanitize_people' : 'cfoc_events_sanitize_meta_' . ( false !== strpos( $key, 'url' ) ? 'url' : ( false !== strpos( $key, 'date' ) || 'cfoc_last_verified' === $key ? 'date' : 'text' ) ) ),
				'auth_callback'     => function () {
					return current_user_can( 'edit_posts' );
				},
			)
		);
	}
}

/**
 * CfOC people: JSON array of {name, group, role}. Returns a clean JSON string ('' if none).
 */
function cfoc_events_sanitize_people( $value ) {
	$list = is_array( $value ) ? $value : json_decode( (string) $value, true );
	if ( ! is_array( $list ) ) {
		return '';
	}
	$out = array();
	foreach ( $list as $p ) {
		if ( is_string( $p ) ) {
			$p = array( 'name' => $p );
		}
		if ( ! is_array( $p ) || empty( $p['name'] ) ) {
			continue;
		}
		$out[] = array(
			'name'  => sanitize_text_field( $p['name'] ),
			'group' => isset( $p['group'] ) ? sanitize_text_field( $p['group'] ) : '',
			'role'  => isset( $p['role'] ) ? sanitize_text_field( $p['role'] ) : '',
		);
	}
	return $out ? wp_json_encode( $out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) : '';
}

function cfoc_events_sanitize_meta_text( $value ) {
	return sanitize_text_field( (string) $value );
}

function cfoc_events_sanitize_meta_url( $value ) {
	return esc_url_raw( trim( (string) $value ) );
}

function cfoc_events_sanitize_meta_date( $value ) {
	$value = trim( (string) $value );
	if ( '' === $value ) {
		return '';
	}
	// Accept YYYY-MM-DD or a full ISO datetime; store YYYY-MM-DD.
	if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})/', $value, $m ) && checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ) {
		return $m[1] . '-' . $m[2] . '-' . $m[3];
	}
	return '';
}

/**
 * Keep end date >= start date, default end to start.
 */
function cfoc_events_fix_end_date( $post_id ) {
	if ( wp_is_post_revision( $post_id ) ) {
		return;
	}
	$start = get_post_meta( $post_id, 'cfoc_start_date', true );
	$end   = get_post_meta( $post_id, 'cfoc_end_date', true );
	if ( $start && ( ! $end || $end < $start ) ) {
		update_post_meta( $post_id, 'cfoc_end_date', $start );
	}
}
add_action( 'save_post_cfoc_event', 'cfoc_events_fix_end_date', 20 );
// Block editor saves meta after save_post, so also run after the REST insert finishes.
add_action(
	'rest_after_insert_cfoc_event',
	function ( $post ) {
		cfoc_events_fix_end_date( $post->ID );
	}
);
