<?php
/**
 * Public read-only endpoints:
 *   GET /wp-json/cfoc-events/v1/events        JSON (?from=YYYY-MM-DD&to=YYYY-MM-DD&type=slug)
 *   GET /wp-json/cfoc-events/v1/ics    iCalendar subscription feed
 *   GET /wp-json/cfoc-events/v1/export        Feed-format JSON of all published events (admins only)
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'rest_api_init',
	function () {
		register_rest_route(
			'cfoc-events/v1',
			'/events',
			array(
				'methods'             => 'GET',
				'permission_callback' => '__return_true',
				'args'                => array(
					'from' => array( 'type' => 'string' ),
					'to'   => array( 'type' => 'string' ),
					'type' => array( 'type' => 'string' ),
				),
				'callback'            => function ( WP_REST_Request $r ) {
					$from = cfoc_events_sanitize_meta_date( (string) $r->get_param( 'from' ) );
					return rest_ensure_response(
						cfoc_events_get(
							array(
								'from' => $from ? $from : current_time( 'Y-m-d' ),
								'to'   => cfoc_events_sanitize_meta_date( (string) $r->get_param( 'to' ) ),
								'type' => sanitize_title( (string) $r->get_param( 'type' ) ),
							)
						)
					);
				},
			)
		);

		register_rest_route(
			'cfoc-events/v1',
			'/ics',
			array(
				'methods'             => 'GET',
				'permission_callback' => '__return_true',
				'callback'            => function () {
					$response = new WP_REST_Response( array( '__cfoc_raw' => cfoc_events_build_ics() ) );
					$response->header( 'Content-Type', 'text/calendar; charset=utf-8' );
					$response->header( 'Content-Disposition', 'inline; filename="cfoc-industry-ics"' );
					return $response;
				},
			)
		);

		register_rest_route(
			'cfoc-events/v1',
			'/export',
			array(
				'methods'             => 'GET',
				'permission_callback' => function () {
					return current_user_can( 'edit_others_posts' );
				},
				'callback'            => function () {
					return rest_ensure_response( cfoc_events_export_array() );
				},
			)
		);
	}
);

/**
 * Serve the ICS body raw instead of JSON-encoding it.
 */
add_filter(
	'rest_pre_serve_request',
	function ( $served, $result ) {
		$data = $result instanceof WP_HTTP_Response ? $result->get_data() : null;
		if ( is_array( $data ) && isset( $data['__cfoc_raw'] ) ) {
			if ( ! headers_sent() ) {
				header( 'Content-Type: text/calendar; charset=utf-8' );
			}
			echo $data['__cfoc_raw']; // phpcs:ignore WordPress.Security.EscapeOutput -- iCalendar body, escaped per RFC 5545 in cfoc_events_build_ics().
			return true;
		}
		return $served;
	},
	10,
	2
);
