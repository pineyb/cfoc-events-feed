<?php
/**
 * iCalendar (RFC 5545) feed of published events (all-day entries).
 */

defined( 'ABSPATH' ) || exit;

function cfoc_events_ics_escape( $s ) {
	$s = wp_strip_all_tags( (string) $s );
	$s = str_replace( array( '\\', ';', ',', "\r\n", "\n", "\r" ), array( '\\\\', '\;', '\,', '\n', '\n', '' ), $s );
	return $s;
}

function cfoc_events_ics_fold( $line ) {
	// Fold at 74 octets without splitting UTF-8 characters.
	$out = '';
	while ( strlen( $line ) > 74 ) {
		$cut = 74;
		while ( $cut > 0 && ( ord( $line[ $cut ] ) & 0xC0 ) === 0x80 ) {
			$cut--;
		}
		$out .= substr( $line, 0, $cut ) . "\r\n ";
		$line = substr( $line, $cut );
	}
	return $out . $line . "\r\n";
}

function cfoc_events_build_ics() {
	$from   = gmdate( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) . ' -60 days' ) );
	$events = cfoc_events_get( array( 'from' => $from ) );
	$host   = wp_parse_url( home_url(), PHP_URL_HOST );
	$stamp  = gmdate( 'Ymd\THis\Z' );

	$ics  = "BEGIN:VCALENDAR\r\n";
	$ics .= "VERSION:2.0\r\n";
	$ics .= "PRODID:-//Center for Offsite Construction//Industry Events//EN\r\n";
	$ics .= "CALSCALE:GREGORIAN\r\n";
	$ics .= "METHOD:PUBLISH\r\n";
	$ics .= cfoc_events_ics_fold( 'X-WR-CALNAME:' . cfoc_events_ics_escape( 'CfOC Offsite Construction Industry Events' ) );
	$ics .= "X-PUBLISHED-TTL:PT12H\r\n";

	foreach ( $events as $e ) {
		$end_excl = gmdate( 'Ymd', strtotime( $e['end'] . ' +1 day' ) );
		$desc     = trim( $e['description'] . ( $e['organizer'] ? "\n\nOrganizer: " . $e['organizer'] : '' ) . ( $e['url'] ? "\n" . $e['url'] : '' ) . "\n\nListed by the Center for Offsite Construction. Confirm details with the organizer." );
		$loc      = $e['online'] ? 'Online' : implode( ', ', array_filter( array( $e['venue'], $e['location'] ) ) );

		$ics .= "BEGIN:VEVENT\r\n";
		$ics .= 'UID:cfoc-event-' . (int) $e['id'] . '@' . $host . "\r\n";
		$ics .= 'DTSTAMP:' . $stamp . "\r\n";
		$ics .= 'DTSTART;VALUE=DATE:' . str_replace( '-', '', $e['start'] ) . "\r\n";
		$ics .= 'DTEND;VALUE=DATE:' . $end_excl . "\r\n";
		$ics .= cfoc_events_ics_fold( 'SUMMARY:' . cfoc_events_ics_escape( $e['title'] ) );
		if ( $loc ) {
			$ics .= cfoc_events_ics_fold( 'LOCATION:' . cfoc_events_ics_escape( $loc ) );
		}
		$ics .= cfoc_events_ics_fold( 'DESCRIPTION:' . cfoc_events_ics_escape( $desc ) );
		if ( $e['url'] ) {
			$ics .= cfoc_events_ics_fold( 'URL:' . esc_url_raw( $e['url'] ) );
		}
		if ( $e['type'] ) {
			$ics .= cfoc_events_ics_fold( 'CATEGORIES:' . cfoc_events_ics_escape( $e['type'] ) );
		}
		$ics .= "TRANSP:TRANSPARENT\r\n";
		$ics .= "END:VEVENT\r\n";
	}

	$ics .= "END:VCALENDAR\r\n";
	return $ics;
}
